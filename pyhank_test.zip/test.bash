# Check and install required packages
virtualenv_path=$(which virtualenv)
if [ ${virtualenv_path} == "" ]; then
	sudo apt install virtualenv > virtualenv_install.txt
fi

python3_path=$(which python3)
if [ ${python3_path} == "" ]; then
	sudo apt install python3 > python3_install.txt
fi

pip3_path=$(which pip3)
if [ ${pip3_path} == "" ]; then
	sudo apt install python3-pip > python3-pip_install.txt
fi

# Create venv
virtualenv venv > venv.txt
. venv/bin/activate

# Install pyhanko library
pip3 install git+https://github.com/MatthiasValvekens/pyHanko > pip3_install.txt

# Create key and cert
openssl ecparam -name secp521r1 -genkey -noout -out best.key
openssl req -x509 -new -noenc -sha256 -days 30 -key best.key -subj "/C=RU/ST=Tatarstan/L=Kazan/O=Company/OU=Best/CN=best.lan" -out best.crt

# Collect key and certificate in pfx
openssl pkcs12 -export -out best.pfx -inkey best.key -in best.crt -passout pass:

# Sign PDF
pyhanko sign addsig --field Sig1 pkcs12 --no-pass document.pdf sig_document.pdf best.pfx # The location of the --no-pass argument matters

# Verifi PDF
pyhanko sign validate --trust best.crt sig_document.pdf

# Exit from venv
deactivate
